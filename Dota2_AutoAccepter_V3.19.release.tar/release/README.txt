

-- USAGE

Open Dota 2, select which match types you'd like to queue for, then press F11 to begin the auto matching process.


-- NOTES

The script waits for Dota 2's flashing window effect on match found event to maximize the game and auto-accept + push notify.
This means the game must be minimized to auto match accept.

-- HOTKEYS

	F11 - Click play, then click find match, then minize the game to allow the auto-accept event to fire
	F10 - Pre-maturely hide any tooltip info notifying you of script events or usage information