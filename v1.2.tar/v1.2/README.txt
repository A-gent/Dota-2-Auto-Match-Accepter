


-- USAGE

Launch Dota 2, start a finding match queue, then press F11 to engage autoclicker.


-- NOTES

This method means you cannot auto-accept when you have the game minimized


-- HOTKEYS

	F11 - Launch script sequence, press again to toggle off.